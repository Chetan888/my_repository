package com.accenture.lkm.exceptions.errors;

public class OutOfMemoryError {

	public static void main(String[] args){
			
		/* (	int j=1,i[];
			while(true)
			{
				
				 i = new int[Integer.MAX_VALUE];
				System.out.println(j++);
				
				
			}*/
		
		String s[]= {"chetan"};
		main(s);
	
		
		

	}

}
