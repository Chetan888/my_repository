package com.accenture.lkm.collection.assignment.map;

public class TransactionMapTester {

	public static void main(String[] args) {
		//TODO
		
		// Create a list to hold transaction
		
		// Add transaction objects to the list
		
		// Create a map to store transactionId and transaction object
		
		// Call print method 
		

	}
}
