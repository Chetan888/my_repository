package com.accenture.lkm.exceptions.customexceptions;

// TODO 1. extend InvalidCredentialsException from Exception
// TODO 2. Press ALT +SHIFT +S , select generate constructor from super class
public class InvalidCredentialsException extends Exception{

	public InvalidCredentialsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}
	
	

}
