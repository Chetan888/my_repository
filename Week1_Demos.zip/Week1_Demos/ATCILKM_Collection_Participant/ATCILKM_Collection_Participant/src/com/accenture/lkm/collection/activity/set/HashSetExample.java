package com.accenture.lkm.collection.activity.set;

import java.util.HashSet;

public class HashSetExample {

	public static void main(String[] args) {
		// Create a set to store account numbers

		HashSet<Long> set = new HashSet<>();
		
		set.add(455299004430L);
		set.add(945984948592L);
		set.add(540954049507L);
		set.add(456534388560L);
		set.add(785653765434L);
		
		
		// Print the set
		
		System.out.println(set);
	}
}