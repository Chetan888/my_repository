package com.accenture.lkm.runtime;

import java.util.InputMismatchException;
import java.util.Scanner;

public class FinallyClause {

		public static void division()
		{
			Scanner sc = new Scanner(System.in);
			int a,b,c;
			
			try
			{
				System.out.println("Enter a and b");
				a=sc.nextInt();
				b=sc.nextInt();
				c=a/b;
				System.out.println("Result := "+c);
				
				
			}catch(InputMismatchException | ArithmeticException a1)
			{
				a1.printStackTrace();
			}
			finally {
				System.out.println("Finally Blocked Called/Executed");
			}
			sc.close();
		}
	
	
	public static void main(String[] args) {
	
			new FinallyClause().division();
				

	}

}
