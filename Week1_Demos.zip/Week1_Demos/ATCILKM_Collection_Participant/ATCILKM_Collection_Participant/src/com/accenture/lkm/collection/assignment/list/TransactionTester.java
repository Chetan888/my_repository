package com.accenture.lkm.collection.assignment.list;


public class TransactionTester {

public static void main(String[] args) {
		
		//TODO
		
		//Create an ArrayList to store transaction objects
		
		//Create transaction objects and add them to the ArrayList
		
		//Call print method of service class which prints transactions corresponding to the account number
		

	}
}
