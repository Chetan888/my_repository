package com.accenture.lkm.collection.assignment.comparable;

import java.util.ArrayList;

public class CourseComparableTester {

public static void main(String[] args) {
		
		//TODO
		
		//Create an ArrayList to store transaction objects
	
		ArrayList<Course> arr = new ArrayList<>();
		
		//Create courses and add them to the ArrayList
		Course c = new Course(4543, "Java", 18, 5545);
		Course c1 = new Course(7894, "SAP", 33, 9445);
		Course c2 = new Course(1060, ".Net", 78, 4745);
		
		arr.add(c);
		arr.add(c1);
		arr.add(c2);
		
		
		
		//Call print method of service class 
		CourseService c3 = new CourseService();
		c3.printAllCoursesSorted(arr);
			

	}
}
