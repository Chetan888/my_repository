package com.accenture.lkm.runtime;

import java.util.Scanner;

public class TryCatch {

	public void division(byte br,byte bn)
	{
		
		try
		{
			
			System.out.println("Quotient := "+br/bn);
			
			
		}catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	public static void main(String[] args) {
	
			TryCatch tr = new TryCatch();
			Scanner sc = new Scanner(System.in);
			byte b,c;
			char ch='o';
			do
			{
					System.out.println("Enter Number 1");
					b=sc.nextByte();
			
					System.out.println("Enter Number 2");
					c=sc.nextByte();
			
					System.out.println("Continue [Y/y]");
					tr.division(b, c);
					System.out.println("Exit [N/n]");
					ch=sc.next().charAt(0);
					if(ch=='n'||ch=='N')
						break;
					
			
			}while(ch=='Y'||ch=='y');
			
			
	
	}
}
