package com.cg.Case;

public class Static_demo {
	
	int empno;
	static int str;
	
	public int getEmpno() {
		return empno;
	}
	
	public void setEmpno(int empno) {
		this.empno = empno;
	}
	
	public static int getStr() {
		return str;
	}
	
	public static void setStr(int str) {
		Static_demo.str = str;
	}
	 
	public static void main(String []args)
	 {
		 Static_demo.setStr(2);
		 System.out.println(""+Static_demo.getStr());
	 }
	

}
