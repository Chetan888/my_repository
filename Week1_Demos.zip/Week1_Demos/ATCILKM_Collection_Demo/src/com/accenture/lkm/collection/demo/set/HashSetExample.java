package com.accenture.lkm.collection.demo.set;
import java.util.HashSet;

public class HashSetExample {

	public static void main(String[] args) {
	
		// create a set to store user id
		HashSet name = new HashSet<>();
		
		name.add("Girish");
		name.add("Komal");
		name.add("Komal");
		name.add(null);
		
		System.out.println(name);
		System.out.println(name.add("Chetan"));
		System.out.println(name.add("Chetan"));
		System.out.println(name);
		
		
		HashSet<String> names = new HashSet<>();
		
		//s1.add("Chetan");
		
		names.add("Girish");
		names.add("Komal");
		names.add("Komal");

		System.out.println(names);
		System.out.println(names.add("Chetan"));
		System.out.println(names.add("Chetan"));
	}

}
