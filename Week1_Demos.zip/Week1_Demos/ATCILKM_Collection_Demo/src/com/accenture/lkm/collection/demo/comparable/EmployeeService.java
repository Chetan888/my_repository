package com.accenture.lkm.collection.demo.comparable;

import java.util.List;

public class EmployeeService {
	
	public void printEmployeeDetails(List<Employee> employeeList)
	{
		employeeList.forEach(employee->{System.out.println("Emp Id :="+employee.getEmp_id()+
		"\n  Emp Name is := "+employee.getEmpName()+"\n  Emp DOJ is:="
		+employee.getYoj()+"\n  Employee Salary is :=  "+employee.getSalary());
			
		});
		
		
	}

}
