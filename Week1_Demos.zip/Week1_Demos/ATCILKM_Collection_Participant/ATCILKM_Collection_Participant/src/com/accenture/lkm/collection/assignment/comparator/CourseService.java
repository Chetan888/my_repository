package com.accenture.lkm.collection.assignment.comparator;

import java.util.Collections;
import java.util.List;
import com.accenture.lkm.collection.assignment.comparator.Course;

public class CourseService {

	// Method which helps to print courses sorted based on course fee

	public void printAllCoursesFeesSorted(List<Course> courses) {

		// TODO
		
		
		
		//Print course name and fee using foreach method
		
			courses.forEach(course->{System.out.println("Course Id :="+course.getCourseId()+
			"\n  Couse Name is := "+course.getCourseName()+"\n  Duration is:="
			+course.getCourseDurationInHours()+"\n  Fees are :=  "+course.getCourseFee());
			});
	
			// Sort the collection by calling Collections.sort method by passing comparator
			// object

			Collections.sort(courses, new SortByDurationComparator());
			
		   // Print course name and fee using foreach method


			courses.forEach(course->{System.out.println("Course Id :="+course.getCourseId()+
			"\n  Couse Name is := "+course.getCourseName()+"\n  Duration is:="
			+course.getCourseDurationInHours()+"\n  Fees are :=  "+course.getCourseFee());
			});
	}

	public void printAllCoursesNamesSorted(List<Course> courses) {

		// TODO

		// Sort the collection by calling Collections.sort method

		// Print course name and fee using foreach method

		// Sort the collection by calling Collections.sort method by passing comparator
		// object

		// Print course name and fee using foreach method

	}

}
