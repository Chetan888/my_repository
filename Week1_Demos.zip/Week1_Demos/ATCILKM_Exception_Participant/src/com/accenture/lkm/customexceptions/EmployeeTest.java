package com.accenture.lkm.customexceptions;

import java.util.Scanner;

public class EmployeeTest {

	public static void findEmp(int empId)throws EmployeeDoesNotExist
	{
		String name[]= {"Chetan","John","Anna"};
		if(empId<0 || empId>2)
		{
			throw new EmployeeDoesNotExist("Employee Does not Exist !! Please enter Valid Emp ID");
		}
		System.out.println(name[empId]);
	}
	
	public static void main(String[] args) throws EmployeeDoesNotExist {
		
		
		try(Scanner sc = new Scanner(System.in);){
		
			int index;
			System.out.println("Enter Index id [1-5]....");
			index=sc.nextInt();
			
			findEmp(index);
		
		}
		catch (Exception e) {
		
			System.out.println(e.getMessage());
		}

	}

}
