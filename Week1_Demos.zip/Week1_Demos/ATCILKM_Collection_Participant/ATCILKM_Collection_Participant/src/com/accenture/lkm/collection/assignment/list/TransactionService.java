package com.accenture.lkm.collection.assignment.list;

import java.util.List;

public class TransactionService {
	
	//This method helps to print transactions corresponding to a particular account

	public void printAllTransactions(List<Transaction> transactions, long accountNumber) {

		/*TODO
		Create a stream on the collection which contains all transaction objects.
		Use a Predicate functional interface to filter transactions 
					corresponding to the account number.*/
		
		transactions.forEach(t->{System.out.println("Receipient ACC Id :="+t.getRecipientAccountNumber()+
				"\n  Sender ACC No is := "+t.getSenderAccountNumber()+"\n  Transaction Amount is:="
				+course.getCourseDurationInHours()+"\n  Fees are :=  "+course.getCourseFee());
				});
		
		
		
		
	}
}
