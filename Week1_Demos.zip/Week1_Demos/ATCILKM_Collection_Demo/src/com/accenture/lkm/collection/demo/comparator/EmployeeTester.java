package com.accenture.lkm.collection.demo.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EmployeeTester {

	public static void main(String[] args) {
		
		
		List<Employee> emp = new ArrayList<Employee>();
		
		emp.add(new Employee(354, "Chetan Sonawane", 25092019, 22.700f));
		emp.add(new Employee(114, "Anagha Shinde", 31092014, 67.780f));
		emp.add(new Employee(984, "John Mark", 21122011, 33.865f));
		emp.add(new Employee(594, "Usman Sheikh", 22032016, 67.122f));
		emp.add(new Employee(3432, "Chang ho", 19072013, 21.763f));
		emp.add(new Employee(1134, "Mark Phelps", 12102015, 75.980f));
		
		
		Collections.sort(emp,new EmployeeIdComparator());
		
		EmployeeService es = new EmployeeService();
		es.printEmployeeDetails(emp);
		
	

	}

}
