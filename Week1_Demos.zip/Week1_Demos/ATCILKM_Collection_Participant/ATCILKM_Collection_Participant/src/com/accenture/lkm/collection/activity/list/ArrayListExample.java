package com.accenture.lkm.collection.activity.list;

import java.util.ArrayList;

public class ArrayListExample {

	public static void main(String[] args) {
		// Create an ArrayList to store names of employees.
		
		ArrayList<String> arr =new ArrayList<>();
		
		arr.add("Chetan Sonawane");
		arr.add("Pushkar Jog");
		arr.add("Natasha Romanoff");
		arr.add("Tony Stark");
		arr.add("Pepper Spots");
		
		System.out.println(arr);
		
		//Print the List
	}
}