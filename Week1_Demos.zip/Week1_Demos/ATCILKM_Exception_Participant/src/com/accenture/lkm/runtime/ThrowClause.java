package com.accenture.lkm.runtime;

import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.accenture.lkm.checked.ThrowsClause;

public class ThrowClause {

	
	public  void division()
	{
		

		Scanner sc = new Scanner(System.in);
		int a,b;
		int q=0;
		
		try
		{
			System.out.println("Enter a and b");
			a=sc.nextInt();
			b=sc.nextInt();
			q=a/b;
			System.out.println("Result := "+q);
			
			
		}catch(InputMismatchException | ArithmeticException a1)
		{
			throw a1;
		}
		finally {
			System.out.println("Finally Blocked Called/Executed");
		}
		sc.close();
		System.out.println("Quotient is "+q);   
	}
	
	
	public static void main(String[] args) {
		
		new ThrowClause().division();

	}

}
