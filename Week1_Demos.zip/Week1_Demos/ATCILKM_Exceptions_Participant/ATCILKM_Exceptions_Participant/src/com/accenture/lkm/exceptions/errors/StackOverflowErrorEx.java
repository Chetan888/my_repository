package com.accenture.lkm.exceptions.errors;

public class StackOverflowErrorEx {

	public static void main(String[] args) {
		
			System.out.println(StackOverflowErrorEx.factorial(5));
	}

	public static int factorial(int n) {
		return n * factorial((n - 1));
	}

}
