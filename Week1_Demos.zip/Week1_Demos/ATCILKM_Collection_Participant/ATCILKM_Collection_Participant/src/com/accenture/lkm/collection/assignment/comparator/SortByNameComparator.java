package com.accenture.lkm.collection.assignment.comparator;

import java.util.Comparator;

public class SortByNameComparator implements Comparator<Course> {

	@Override
	public int compare(Course o1, Course o2) {
		// TODO Auto-generated method stub
		
		if(o1.getCourseName().length()>o2.getCourseName().length())
			return 1;
		else if(o1.getCourseName().length()>o2.getCourseName().length())
			return -1;
		else
			return 0;
	}

	//TODO
	
	//Override compare method to sort based on course name

}
