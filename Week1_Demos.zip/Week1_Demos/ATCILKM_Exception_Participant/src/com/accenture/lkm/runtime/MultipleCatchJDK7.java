package com.accenture.lkm.runtime;

public class MultipleCatchJDK7 {

	public static void main(String[] args) {
	

	}

}
