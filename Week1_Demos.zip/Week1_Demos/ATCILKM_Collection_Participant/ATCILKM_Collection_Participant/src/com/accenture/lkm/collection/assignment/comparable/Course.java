package com.accenture.lkm.collection.assignment.comparable;
//TODO

//implement Comparable interface 

public class Course implements Comparable<Course> {

	private int courseId;
	private String courseName;
	private int courseDurationInHours;
	private int courseFee;

	public Course(int courseId, String courseName, int courseDurationInHours, int courseFee) {
		this.courseId = courseId;
		this.courseName = courseName;
		this.courseDurationInHours = courseDurationInHours;
		this.courseFee = courseFee;
	}

	public int getCourseId() {
		return courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public int getCourseDurationInHours() {
		return courseDurationInHours;
	}

	public int getCourseFee() {
		return courseFee;
	}

	@Override
	public int compareTo(Course o) {
		// TODO Auto-generated method stub
		if(o.getCourseName().equalsIgnoreCase("Java"))
			return 1;
		else if(o.getCourseName().equalsIgnoreCase("SAP"))
			return -1;
		else
			return 0;
	}

	//TODO
	
	//Override compareTo method


}
