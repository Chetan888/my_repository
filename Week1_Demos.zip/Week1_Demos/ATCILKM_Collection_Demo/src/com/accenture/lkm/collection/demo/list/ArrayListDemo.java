package com.accenture.lkm.collection.demo.list;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo {
	
	static int i=0;
	public static void main(String[] args) {
	
		ArrayList<String> a = new ArrayList<>();
		
		a.add("Chetan");
		a.add("Girish");
		a.add("Meghna");
		a.add("Akash");
		
		//System.out.println(a);
		
		Iterator  i = a.iterator();
	
		/* while (i.hasNext()) {
			
			String name=(String)i.next();
			System.out.println(name);
			
		} */
		
		a.forEach((x)->System.out.println(x.toUpperCase()));
		
		
	}

}
