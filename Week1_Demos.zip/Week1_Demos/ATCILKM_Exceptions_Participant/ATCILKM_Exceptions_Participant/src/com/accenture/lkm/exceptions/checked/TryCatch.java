package com.accenture.lkm.exceptions.checked;

import java.io.FileWriter;
import java.io.IOException;

public class TryCatch {
	public static void write(String fileName)throws IOException {
		// TODO 1. create a FileWriter object in append mode by passing fileName as argument
		
		FileWriter f = new FileWriter(fileName, true);
	}

	public static void main(String[] args) {
		try {
			write("src/files/users.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
