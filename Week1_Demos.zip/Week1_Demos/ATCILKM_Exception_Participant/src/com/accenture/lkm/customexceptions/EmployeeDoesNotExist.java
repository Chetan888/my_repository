package com.accenture.lkm.customexceptions;

public class EmployeeDoesNotExist extends Exception{

	public EmployeeDoesNotExist(String message) {
		super(message);
	}

	
	
	

}
