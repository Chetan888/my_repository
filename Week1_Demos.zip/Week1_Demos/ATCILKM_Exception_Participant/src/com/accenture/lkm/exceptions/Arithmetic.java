package com.accenture.lkm.exceptions;

import java.util.Scanner;

public class Arithmetic {
	
	public void displayDivision(byte br,byte nr)
	{
		
		int res;
		if(nr==0)
		{
			System.out.println("Can't Divide by 0");
		}
		else
		{
			res=br/nr;
			System.out.println("Division :="+res);
		}
	}
	public static void main(String[] args) {

				char ch='c';
				Arithmetic ar = new Arithmetic();
				Scanner sc = new Scanner(System.in);
				
			do {
				
			
				System.out.println("Enter Numbers Between -127 to 128");
				byte b=sc.nextByte();
				
				System.out.println("Enter Numbers Between -127 to 128");
				byte b1=sc.nextByte();
				
				ar.displayDivision(b, b1);
				
				System.out.println("Enter [Y] / [y] for Continue");
				System.out.println("Enter [n] / [N] for Exit");
				ch=sc.next().charAt(0);
				
				if(ch=='N' || ch=='n')
					break;
				
			}while(ch=='Y' || ch=='y');	
			

	}

}
