package com.accenture.lkm.collection.demo.comparable;

public class Employee implements Comparable<Employee> {
	
	private int emp_id;
	private String empName;
	private int yoj;
	private float salary;
	
	public Employee(int emp_id, String empName, int yoj, float salary) {
		super();
		this.emp_id = emp_id;
		this.empName = empName;
		this.yoj = yoj;
		this.salary = salary;
	}
	
	
	public int getEmp_id() {
		return emp_id;
	}
	
	
	public String getEmpName() {
		return empName;
	}
	
	
	
	public int getYoj() {
		return yoj;
	}
	

	
	public float getSalary() {
		return salary;
	}


	@Override
	public int compareTo(Employee emp) {
		
		if(this.emp_id>emp.emp_id)
			return 1;
		else if(this.emp_id<emp.emp_id)
			return -1;
		else
			return 0;
	}

	

}
