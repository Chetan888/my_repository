package com.accenture.lkm.collection.demo.map;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class HashMapExample {

	public static void main(String[] args) {
		
		Map<Integer,String> directory = new HashMap<>();
		
		directory.put(43323, "Mohommad ali");
		directory.put(65332, "Ross Geller");
		directory.put(27653, "Jennifer won");
		directory.put(98765, "Sonam Kapoor");
		directory.put(12393, "Vincent Roy");
		directory.put(76553, "Stacy Cristine");
		directory.put(76553, "Stacy Cristine");
		// print all elements
		
		directory.forEach((k,v)->System.out.println("Id is := "+k +"  Name is :="+v));
				
		//get all keys
		
		Set<Integer> keys = directory.keySet();
		
		//Create Iterator to Iterate
		
		Iterator<Integer> itr = keys.iterator();
		
		while(itr.hasNext())
		{
			
			Integer key = itr.next();
			String name = directory.get(key);
			System.out.println("Id := "+key +" Name:="+name);
		}
		
	}

}
