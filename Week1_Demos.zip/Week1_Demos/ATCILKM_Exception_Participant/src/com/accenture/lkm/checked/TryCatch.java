package com.accenture.lkm.checked;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class TryCatch {

	public static void read()
	{
		
		try {
			
				FileReader fr = new FileReader("C:\\ADFJava_ChetanSonawane_Demos\\Week1_Demos"
						+ "\\ATCILKM_Exception_Participant\\src\\files\\users.txt");
			
				int ch;
				while((ch=fr.read())!=-1){
					
				System.out.print(""+(char)ch);
				
			}
		
		} 
		catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} 
		catch (IOException e) {
			
			e.printStackTrace();
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args) {
		
				
				TryCatch.read();

	}

}
