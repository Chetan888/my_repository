package com.accenture.lkm.collection.assignment.comparable;

import java.util.Collections;
import java.util.List;

public class CourseService {
	
	//Method which helps to print courses sorted based on course fee
	
	public void printAllCoursesSorted(List<Course> courses) {
		
		//TODO
		
		//Sort the collection by calling Collections.sort method

		Collections.sort(courses);
		
		//Print course name and fee using foreach method
		
	courses.forEach(course->{System.out.println("Course Id :="+course.getCourseId()+
	"\n  Couse Name is := "+course.getCourseName()+"\n  Duration is:="
	+course.getCourseDurationInHours()+"\n  Fees are :=  "+course.getCourseFee());
		
		
		
		
		
		
		});
	}
}