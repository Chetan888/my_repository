package com.accenture.lkm.exceptions.customexceptions;

import java.util.Scanner;

public class User {
	String username = null;
	String password = null;

	// TODO 1. if credentials are invalid, raise InvalidCredentialsException
	public void validate()throws InvalidCredentialsException {

		if (username.equals("tom") && password.equals("tom@123")) {
			System.out.println("valid");
		} else {
			System.out.println("invalid");
			throw new InvalidCredentialsException("Credentials are Invalid !!!");
			
		}
	}

	public void input() {
		try (Scanner sc = new Scanner(System.in);) {
			System.out.println("Enter username");
			username = sc.next();

			System.out.println("Enter password");
			password = sc.next();
		}
	}

	public static void main(String[] args) {
		try {
			User user = new User();
			user.input();
			user.validate();
		} catch (InvalidCredentialsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
