package com.accenture.lkm.collection.assignment.comparator;

import java.util.ArrayList;

public class CourseComparatorTester {
	public static void main(String[] args) {

		// TODO

		// Create an ArrayList to store transaction objects
		
		
		ArrayList<Course> arr = new ArrayList<>();

		// Create courses and add them to the ArrayList

		Course c = new Course(45654, "Java", 54, 10093);
		Course c1 = new Course(57656, "SAP", 23, 78657);
		Course c2 = new Course(78553, "Salesforcsce", 45, 5223);
		Course c3 = new Course(32424, ".Net", 74, 32454);
		
		
		// Call print method of service class which prints transactions corresponding to
		CourseService cs = new CourseService();
		cs.printAllCoursesFeesSorted(arr);
		
		// the account number

	}
}
